import os
from flask import Flask

def create_app():
    # Define a pasta 'views' como o diretório de templates Jinja2
    app = Flask(__name__, template_folder="views", static_folder="static")

    # Chave secreta necessária para assinar os cookies de sessão
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "chave_secreta_super_segura_shopee_dev")

    # Registro dos Blueprints
    from app.controllers.auth_controller import auth_bp
    from app.controllers.main_controller import main_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)

    return app
from werkzeug.security import generate_password_hash, check_password_hash

# Base de usuários de teste em memória
# Senha padrão para todos: "123456"
USERS_DB = [
    {
        "id": 1,
        "username": "admin@shopee.com",
        "name": "Administrador Shopee",
        "password_hash": generate_password_hash("123456")
    },
    {
        "id": 2,
        "username": "vendedor@shopee.com",
        "name": "Loja Vendedora Oficial",
        "password_hash": generate_password_hash("123456")
    }
]

class UserModel:
    @staticmethod
    def find_by_username(username: str):
        return next((user for user in USERS_DB if user["username"].lower() == username.lower()), None)

    @staticmethod
    def find_by_id(user_id: int):
        return next((user for user in USERS_DB if user["id"] == user_id), None)

    @staticmethod
    def verify_password(stored_hash: str, plain_password: str) -> bool:
        return check_password_hash(stored_hash, plain_password)
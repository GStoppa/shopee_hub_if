from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from app.models.user_model import UserModel

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    # Se já estiver logado, redireciona direto para a tela de bem-vindo
    if "user_id" in session:
        return redirect(url_for("main.welcome"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = UserModel.find_by_username(username)

        if user and UserModel.verify_password(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            session["user_email"] = user["username"]
            
            flash(f"Bem-vindo de volta, {user['name']}!", "success")
            return redirect(url_for("main.welcome"))

        flash("E-mail ou senha incorretos.", "danger")

    return render_template("auth/login.html")

@auth_bp.route("/logout", methods=["GET", "POST"])
def logout():
    session.clear()
    flash("Sessão encerrada com sucesso.", "info")
    return redirect(url_for("auth.login"))